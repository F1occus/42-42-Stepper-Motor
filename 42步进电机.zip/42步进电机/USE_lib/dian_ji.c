#include "dian_ji.h"
#include "tim.h"

void MotorCtrl(int direct,int speed)
{
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, direct);
	__HAL_TIM_SetAutoreload(&htim2, speed);		//����ARR
}
