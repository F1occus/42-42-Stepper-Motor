#ifndef __MY_LIB_H__
#define __MY_LIB_H__

#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "dian_ji.h"
#include "stdio.h"

extern int ITCnt;	//�жϼ���



#endif
